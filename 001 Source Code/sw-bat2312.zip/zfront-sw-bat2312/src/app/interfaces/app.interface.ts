// export interface User {
//     id?: string;
//     username: string;
//     password: string;
//     firstName?: string;
//     lastName?: string;
//     token?: string;
//     devices?: string[];
//   }
//   export interface GeneralData{
//     key: string;
//     value: any;
//   }
//   export interface DbDto {
//     id?: any;
//     // dbName: string;
//     collectionName?: string;
//     timeInterval?: number[];
//     time?: number;
//     key: string;
//     value?: any;
//     range?:number;
//   }

//   export interface Device {
//     deviceName: string;
//     deviceId: string;
//     master:string;

//     description?: string;
//     sensors?: {
//       sensorName?:string;
//       sensorType?:string;
//       unit?:string
//     }[];
//     users?:{userName:string}[];
//     isEdit?: boolean;
//     isSelected?: boolean;
//   }

//   export interface TableButtonAction {
//     key: string;
//     value?: any
//   }

//   export interface TableColumn
//   {
//      columnDef: string; // 특별한 문제없다면 columnDef 과 row[columnDef] 로 사용
//      header: string; // column name
//      unit?: string; // header와 함께 사용할 unit
//      type?: string; // input type "button", "checkbox", "color", "date", "datetime-local", "email", "file", "image", "month", "number", "password", "radio", "range", "reset", "search", "submit", "tel", "text", "time", "url", "week" 
//   }