/* 
Angular CLI: 15.2.7
Node: 18.17.1
Package Manager: npm 10.1.0
OS: win32 x64
*/
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { environment } from './environments/environment';
import { LoggerService } from './services/common.service';
import { IMqttServiceOptions, MqttModule } from 'ngx-mqtt';
import { MyCardComponent } from './home/my-card/my-card.component';
import { MaterialModule } from './libs/material/material.module';
import { HomeComponent } from './home/home.component';

const MQTT_WS_OPTIONS: IMqttServiceOptions = environment.mqttWsConfig.connection;

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    MyCardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MqttModule.forRoot(MQTT_WS_OPTIONS),
    MaterialModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
  
  private logger = new LoggerService(this.constructor.name); //'trace', 'debug','error','warning','info' , this.constructor.name
  
  constructor(){this.logger.trace('constructor')}; //constructor
 }
