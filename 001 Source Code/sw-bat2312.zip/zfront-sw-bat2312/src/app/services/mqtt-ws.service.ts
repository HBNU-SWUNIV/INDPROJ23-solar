import { Injectable } from '@angular/core';
import {
  IMqttMessage,
  MqttService,
  IPublishOptions,
} from 'ngx-mqtt';
import { Subscription } from 'rxjs';
import { CommonService, LoggerService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class MqttWsService {

  private subscription!: Subscription;

  constructor(
    private mqttService: MqttService,
    private common: CommonService) {
    this.common.mqttSubRequest.subscribe((topic: string) => {
      this.subscribe(topic)
    })

  } // constructor

  subscribe(topic: string, qos: number = 0) {
    this.subscription = this.mqttService.observe(topic).subscribe((message: IMqttMessage) => {
      let payload = JSON.parse(message.payload.toString()); // {"name":"IamAboy"} key에 "" 있어야만 함
      console.log(`payload.string: ${JSON.stringify(payload)}`);
      this.common.mqttRecieved.next({ topic: message.topic, payload });
    });
  } // subscribe()

  unsubscribe(topic: string) {
    this.subscription.unsubscribe()
  } //unsubscribe()

  publish(topic: string, qos: number, payload: any) {
    this.mqttService.unsafePublish(topic, payload, { qos } as IPublishOptions)
  }
} // MqttWsService class
