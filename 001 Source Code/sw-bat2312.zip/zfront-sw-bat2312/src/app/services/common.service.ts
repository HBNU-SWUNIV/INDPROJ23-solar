import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { loggerLevel } from '../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  private logger = new LoggerService(this.constructor.name); //'trace', 'debug','error','warning','info' , this.constructor.name

  devices: string[] = []; //db.devices
  deviceDataUpdated:any = new Subject();
  mqttRecieved:any = new Subject();
  mqttSubRequest:any = new Subject(); 
  updateFlag:any = new Subject();

  constructor() { 
    this.logger.trace(`constructor`);
  }

} // CommonService

export class LoggerService {

  private location: string = '';
  private logLevelList: string[] = ['trace', 'debug', 'error', 'warning', 'info'];
  private logLevel: number = this.logLevelList.indexOf(loggerLevel);

  trace(message: string) {
    if (this.logLevel <= this.logLevelList.indexOf('trace')) {
      let logEntry = this.createLogStatement('trace', message)
      console.debug(logEntry);
      return logEntry;
    }
    return
  }

  debug(message: string) {
    if (this.logLevel <= this.logLevelList.indexOf('debug')) {
      let logEntry = this.createLogStatement('debug', message)
      console.debug(logEntry);
      return logEntry;
    }
    return
  }

  error(message: string) {
    if (this.logLevel <= this.logLevelList.indexOf('error')) {
      let logEntry = this.createLogStatement('error', message)
      console.error(logEntry);
      return logEntry;
    }
    return
  }

  warn(message: string) {
    if (this.logLevel <= this.logLevelList.indexOf('warning')) {
      let logEntry = this.createLogStatement('warning', message)
      console.warn(logEntry);
      return logEntry;
    }
    return
  }

  info(message: string) {
    if (this.logLevel <= this.logLevelList.indexOf('info')) {
      let logEntry = this.createLogStatement('info', message)
      console.info(logEntry);
      return logEntry;
    }
    return
  }

  createLogStatement(level: string, message: string) {
    let SEPARATOR = " ";
    let date = this.getCurrentDate();
    return this.location + "[" + level + "]" + SEPARATOR + date + SEPARATOR + message;
  }

  getCurrentDate() {
    let now = new Date();
    return "[" + now.toLocaleString() + "]";
  }

  constructor(location: string) {
    this.location = "@" + location ;
  }
} //LoggerService