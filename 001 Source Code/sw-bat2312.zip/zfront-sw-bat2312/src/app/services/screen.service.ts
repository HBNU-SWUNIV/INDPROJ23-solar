import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';

@Injectable({
  providedIn: 'root',
})
export class ScreenService {
  screenSizeSubj = new Subject<any>(); //"Web"/"Tablet"/"Handset"
  screenOrientationSubj = new Subject<any>(); //"Portrait"/"Ladscape"

  constructor(private breakpointObserver: BreakpointObserver) {
    breakpointObserver
      .observe([
        Breakpoints.HandsetLandscape,
        Breakpoints.TabletLandscape,
        Breakpoints.WebLandscape,
        Breakpoints.HandsetPortrait,
        Breakpoints.TabletPortrait,
        Breakpoints.WebPortrait,
      ])
      .subscribe((r) => {
        //r={matches, breakpoints}
        // console.log(JSON.stringify(r));
        if (
          r.breakpoints[Breakpoints.HandsetPortrait] ||
          r.breakpoints[Breakpoints.HandsetLandscape]
        ) {
          this.screenSizeSubj.next('Handset');
        } else if (
          r.breakpoints[Breakpoints.TabletPortrait] ||
          r.breakpoints[Breakpoints.TabletLandscape]
        ) {
          this.screenSizeSubj.next('Tablet');
        } else {
          this.screenSizeSubj.next('Web');
        }
        if (
          r.breakpoints[Breakpoints.HandsetPortrait] ||
          r.breakpoints[Breakpoints.TabletPortrait] ||
          r.breakpoints[Breakpoints.WebPortrait]
        ) {
          this.screenOrientationSubj.next('Portrait');
        } else {
          this.screenOrientationSubj.next('Landscape');
        }
      }); //subscribe
    this.screenSizeSubj.subscribe((r) => {
      console.log(`screen size: ${r}`);
    });
    this.screenOrientationSubj.subscribe((r) => {
      console.log(`screen orientation: ${r}`);
    });
  } // constructor

    fullScreen(elem:any){

        if(elem.requestFullScreen) {
          elem.requestFullScreen();
          console.log('1');
        } else if(elem.webkitRequestFullScreen ) {
          elem.webkitRequestFullScreen();
          console.log('2');
        } else if(elem.mozRequestFullScreen) {
          elem.mozRequestFullScreen();
          console.log('3');
        } else if (elem.msRequestFullscreen) {
          elem.msRequestFullscreen(); // IE
          console.log('4');
        }
        console.log('-o-');
      }
    
      fullScreenExit(elem:any){
        if (document.exitFullscreen){
          document.exitFullscreen();
          console.log('1');
        // }else if(document.cancelFullScreen) {
        //  document.cancelFullScreen();
        //   console.log('1-1');
        // } else if(document.webkitCancelFullScreen ) {
        //  document.webkitCancelFullScreen();
        //   console.log('2');
        // } else if(document.mozCancelFullScreen) {
        //  document.mozCancelFullScreen();
        //   console.log('3');
        // } else if (document.msExitFullscreen) {
        //   elem.msExitFullscreen(); // IE 
        //   console.log('4');       
        }
        console.log('-x-');
      }
    
}
