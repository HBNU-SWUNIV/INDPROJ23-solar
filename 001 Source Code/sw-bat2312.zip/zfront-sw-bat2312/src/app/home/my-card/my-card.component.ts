import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-my-card',
  templateUrl: './my-card.component.html',
  styleUrls: ['./my-card.component.scss']
})
export class MyCardComponent {
  @Input('title') title: string='no title'
  @Input('content') content: any= {key:"item",value:"none"}

  onClick(){} // onClick

} //calss MyCardComponent
