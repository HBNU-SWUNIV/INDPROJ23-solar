import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { MatDrawerMode } from '@angular/material/sidenav';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ScreenService } from 'src/app/services/screen.service';
import { MqttWsService } from '../services/mqtt-ws.service';
import { CommonService, LoggerService } from '../services/common.service';
import { environment } from '../environments/environment';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent {
    batteryState = {
        V_battery: "no Op",
        I_charge: "no Op",
        I_discharge: "no Op"
    };
    boxInfos = [
        {
            buttonName: "사용신청",
            message: " 사용가능"
        },
        {
            buttonName: "사용신청",
            message: " 사용가능"
        },
        {
            buttonName: "사용중",
            message: " 충전중"
        },
    ]

    door1: Array<string> = ['0', '0', '0'];
    door2: Array<string> = ['0', '0', '0'];
    door_open_closeed: Array<string> = ['1', '2', '0']

    startTime1: number = 0;
    startTime2: number = 0;

    bibon: Array<string> = ['1233', '2344'];


    constructor(
        private common: CommonService,
        private mqtt: MqttWsService
    ) {
        this.mqtt.subscribe(environment.mqttWsConfig.subTopic);
        this.common.mqttRecieved.subscribe((obj: any) => {
            // console.log(`recieved in home-cpmponent: ${JSON.stringify(obj)}`)
            if (obj.payload.reportData) {
                this.batteryState.I_charge = obj.payload.reportData.SolarCurrent;
                this.batteryState.V_battery = obj.payload.reportData.BatteryVoltage;
                this.batteryState.I_discharge = obj.payload.reportData.BatteryCurrent;
                let door = obj.payload.reportData.Charger_1;
                if (this.door1[2] != door) {
                    this.door1.shift();
                    this.door1.push(door);
                    console.log(JSON.stringify(this.door1));

                    if (this.arrayCompare(this.door1,this.door_open_closeed)) {
                        console.log("door closed")
                        if (this.boxInfos[0].buttonName == '사용신청') {
                            this.boxInfos[0].buttonName = '사용중';
                            this.boxInfos[0].message = "충전중";
                            this.startTime1 = Number(Date.now());
                            console.log(this.boxInfos[0].buttonName)
                        } else if (this.boxInfos[0].buttonName == '사용중') {
                            this.boxInfos[0].buttonName = '사용신청';
                            this.boxInfos[0].message = "사용가능";
                            console.log(this.boxInfos[0].buttonName)
                        }
                    }
                }
                door = obj.payload.reportData.Charger_2;
                if (this.door2[2] != door) {
                    this.door2.shift();
                    this.door2.push(door);
                    console.log(JSON.stringify(this.door2));

                    if (this.arrayCompare(this.door2, this.door_open_closeed)) {
                        if (this.boxInfos[1].buttonName == '사용신청') {
                            this.boxInfos[1].buttonName = '사용중';
                            this.boxInfos[1].message = "충전중";
                            this.startTime2 = Number(Date.now());
                        } else if (this.boxInfos[1].buttonName == '사용중') {
                            this.boxInfos[1].buttonName = '사용신청';
                            this.boxInfos[1].message = "사용가능";
                        }
                    }
                }
            }
        })

        setInterval(() => {
            if (this.boxInfos[0].buttonName == "사용중") {
                this.boxInfos[0].message = `충전중 : ${Math.round((Number(Date.now()) - this.startTime1) / 60 / 1000)
                    } 분 경과`
            }
            if (this.boxInfos[1].buttonName == "사용중") {
                this.boxInfos[1].message = `충전중 : ${Math.round((Number(Date.now()) - this.startTime2) / 60 / 1000)
                    } 분 경과`
            }
            // console.log(JSON.stringify(this.boxInfos))
        }, 1000)

    } // constructor()

    onClick(indx: number) {
        confirm(`boc ${indx + 1}의 비번은 "${this.bibon[indx]}" 입니다.`);
    } //onClick()

    arrayCompare(a: Array<string>, b: Array<string>): boolean {
        for (let i = 0; i < a.length; i++) {
            if (a[i] !== b[i]) {
                return false;
            }
        }
        return true
    }

}// class HomeComponent