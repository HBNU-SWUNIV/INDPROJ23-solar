export const DeviceColumns =
    [
        {
            key: 'deviceName',
            type: 'text',
            label: 'Device Name'
        },
        {
            key: 'deviceId',
            type: 'text',
            label: 'Device ID'
        },
        {
            key: 'master',
            type: 'text',
            label: 'Master'
        },
        {
            key: 'users',
            type: 'users',
            label: 'Users'
        },
        {
            key: 'sensors',
            type: 'sensors',
            label: 'Sensors'
        },
    ]

export const SensorColumns =
    [

        {
            key: 'name',
            type: 'text',
            label: 'Sensor Name'
        },
        {
            key: 'type',
            type: 'text',
            label: 'Mesurement Type'
        },
        {
            key: 'unit',
            type: 'text',
            label: 'Unit'
        },

    ]

export const UserColumns =
    [

        {
            key: 'username',
            type: 'text',
            label: 'User Name'
        },

    ]