import { IMqttServiceOptions } from "ngx-mqtt";

export const projName='sfarm2311';

export const loggerLevel='trace'; //'trace', 'debug','error','warning','info'

export const environment  = {
  apiConfig: {
    url: `http://localhost:3000/api/v1/${projName}`,
  },

  mqttWsConfig: {
    connection:<IMqttServiceOptions> {
      hostname: 'broker.emqx.io', 
      port: 8083, // emqx 8083 for ws, 8084 for wss
      path: '/mqtt', // not a part of the topic 
      protocol: 'ws'
    },
    subTopic:'mqtt/v1/solarpower2311/report/id/+'
  },
  dbConfig:{
    dbName:'sfarm2309' , // not used, hust for reference, it is used in the backend server 
    dbPath:'api/v1/db'
  }

};